# ft_package

## Overview

A sample test package for counting occurrences in a list.

## Installation

You can install this package using pip:

```bash
pip install ft_package